""".. moduleauthor:: You!"""

from optcom.effects.abstract_effect import AbstractEffect

class Relaxation(AbstractEffect):
    """Someone should do this code. I can do this code. I could actually do
    it. Ok, I'm coding.

    .. figure::  images/trollface_dance.gif
       :scale:  60%
       :align:  center

    """

    def __init__(self) -> None:
        return None
