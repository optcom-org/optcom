import optcom.field as fld
from optcom.utils.csv_fit import CSVFit


temporal_power = fld.Field.temporal_power
spectral_power = fld.Field.spectral_power
phase = fld.Field.phase
