# Solver
DEFAULT_SOLVER: str = "euler"

RK4IP_GNLSE: bool = False
