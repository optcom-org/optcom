#field types
OPTI: int = 43
ELEC: int = 44
ANY: int = 45
